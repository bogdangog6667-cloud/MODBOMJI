package com.musormod;

import net.minecraft.block.BlockState;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.tileentity.TileEntity;

public class BusinessTile extends TileEntity {
    public long last = -1L;

    public BusinessTile() {
        super(ModTiles.BUSINESS.get());
    }

    @Override
    public void read(BlockState state, CompoundNBT nbt) {
        super.read(state, nbt);
        last = nbt.contains("Last") ? nbt.getLong("Last") : -1L;
    }

    @Override
    public CompoundNBT write(CompoundNBT nbt) {
        super.write(nbt);
        nbt.putLong("Last", last);
        return nbt;
    }
}
