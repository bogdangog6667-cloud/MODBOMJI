package com.musormod;

import javax.annotation.Nullable;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.World;

/** Бизнес-сейф: копит гривны (rate за каждые 10 секунд), снимается правым кликом. */
public class BusinessBlock extends Block {
    private static final long PERIOD = 200L;   // 10 секунд
    private static final long CAP = 5000L;     // максимум в сейфе
    private final int rate;

    public BusinessBlock(AbstractBlock.Properties props, int rate) {
        super(props);
        this.rate = rate;
    }

    @Override
    public boolean hasTileEntity(BlockState state) {
        return true;
    }

    @Override
    public TileEntity createTileEntity(BlockState state, IBlockReader world) {
        return new BusinessTile();
    }

    @Override
    public void onBlockPlacedBy(World w, BlockPos pos, BlockState st, @Nullable LivingEntity placer, ItemStack stack) {
        TileEntity t = w.getTileEntity(pos);
        if (t instanceof BusinessTile) {
            ((BusinessTile) t).last = w.getGameTime();
            t.markDirty();
        }
    }

    @Override
    public ActionResultType onBlockActivated(BlockState state, World world, BlockPos pos,
                                             PlayerEntity player, Hand hand, BlockRayTraceResult hit) {
        if (world.isRemote) {
            return ActionResultType.SUCCESS;
        }
        TileEntity t = world.getTileEntity(pos);
        if (t instanceof BusinessTile) {
            BusinessTile b = (BusinessTile) t;
            long now = world.getGameTime();
            if (b.last < 0) {
                b.last = now;
            }
            long amount = Math.min(CAP, ((now - b.last) / PERIOD) * rate);
            if (amount > 0) {
                b.last = now;
                b.markDirty();
                long left = amount;
                while (left > 0) {
                    int n = (int) Math.min(64L, left);
                    ItemStack s = new ItemStack(ModItems.HRYVNIA.get(), n);
                    if (!player.addItemStackToInventory(s)) {
                        player.dropItem(s, false);
                    }
                    left -= n;
                }
                player.sendStatusMessage(new StringTextComponent("Прибыль снята: " + amount + " гривен"), true);
            } else {
                player.sendStatusMessage(new StringTextComponent("Прибыли пока нет, подожди немного"), true);
            }
        }
        return ActionResultType.SUCCESS;
    }
}
