package com.musormod;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MusorMod.MODID);

    public static final RegistryObject<Block> TRASH_PILE = BLOCKS.register("trash_pile",
            () -> new Block(AbstractBlock.Properties.create(Material.IRON)
                    .hardnessAndResistance(0.4F)
                    .sound(SoundType.METAL)));

    public static final RegistryObject<Block> STEEL_BEAM = BLOCKS.register("steel_beam",
            () -> new Block(AbstractBlock.Properties.create(Material.IRON)
                    .hardnessAndResistance(5.0F, 8.0F)
                    .sound(SoundType.METAL)));

    public static final RegistryObject<Block> BIZ_KIOSK = BLOCKS.register("biz_kiosk",
            () -> new BusinessBlock(bizProps(), 1));
    public static final RegistryObject<Block> BIZ_SHOP = BLOCKS.register("biz_shop",
            () -> new BusinessBlock(bizProps(), 3));
    public static final RegistryObject<Block> BIZ_SERVICE = BLOCKS.register("biz_service",
            () -> new BusinessBlock(bizProps(), 6));

    private static AbstractBlock.Properties bizProps() {
        return AbstractBlock.Properties.create(Material.IRON)
                .hardnessAndResistance(3.0F, 6.0F)
                .sound(SoundType.METAL);
    }
}
