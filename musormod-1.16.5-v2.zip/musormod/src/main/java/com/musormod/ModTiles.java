package com.musormod;

import net.minecraft.tileentity.TileEntityType;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModTiles {
    public static final DeferredRegister<TileEntityType<?>> TILES =
            DeferredRegister.create(ForgeRegistries.TILE_ENTITIES, MusorMod.MODID);

    public static final RegistryObject<TileEntityType<BusinessTile>> BUSINESS = TILES.register("business",
            () -> TileEntityType.Builder.create(BusinessTile::new,
                    ModBlocks.BIZ_KIOSK.get(), ModBlocks.BIZ_SHOP.get(), ModBlocks.BIZ_SERVICE.get()).build(null));
}
