package com.musormod;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.LanternBlock;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.merchant.villager.VillagerEntity;
import net.minecraft.entity.merchant.villager.VillagerProfession;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MerchantOffer;
import net.minecraft.item.MerchantOffers;
import net.minecraft.util.Direction;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.world.server.ServerWorld;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Строит большой город 160x160 по очереди (несколько задач за тик, чтобы не вешать сервер). */
@Mod.EventBusSubscriber(modid = MusorMod.MODID)
public class CityBuilder {
    private static final ArrayDeque<Runnable> QUEUE = new ArrayDeque<>();
    private static final int CELL = 32;
    private static final int ROAD = 6;
    private static final int CELLS = 5;
    private static final int SIZE = CELL * CELLS;
    private static final int FLAGS = 2 | 16;
    private static final int BIG = 9999999;

    private static final Block[] WALLS = {
            Blocks.BRICKS, Blocks.STONE_BRICKS, Blocks.WHITE_CONCRETE,
            Blocks.LIGHT_GRAY_CONCRETE, Blocks.YELLOW_TERRACOTTA, Blocks.GRAY_CONCRETE
    };
    private static final Block[] ROOFS = {
            Blocks.DARK_OAK_PLANKS, Blocks.COBBLESTONE, Blocks.STONE_BRICKS
    };

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) {
            return;
        }
        for (int i = 0; i < 2 && !QUEUE.isEmpty(); i++) {
            QUEUE.poll().run();
        }
    }

    public static boolean start(ServerWorld w, BlockPos c, PlayerEntity p) {
        if (!QUEUE.isEmpty()) {
            if (p != null) {
                p.sendStatusMessage(new StringTextComponent("Город ещё строится, подожди"), true);
            }
            return false;
        }
        final int gy = c.getY();
        final int ox = c.getX() - SIZE / 2;
        final int oz = c.getZ() - SIZE / 2;
        final Random r = new Random(w.getSeed() ^ c.toLong());

        final int[][] types = new int[CELLS][CELLS];
        for (int cx = 0; cx < CELLS; cx++) {
            for (int cz = 0; cz < CELLS; cz++) {
                int v = r.nextInt(10);
                types[cx][cz] = v < 6 ? 0 : v < 7 ? 1 : v < 8 ? 2 : v < 9 ? 3 : 4;
            }
        }
        // гарантированные магазины и скупки в разных частях города
        types[1][1] = 2;
        types[3][3] = 1;
        types[1][3] = 2;
        types[3][1] = 1;
        types[2][2] = 5; // площадь

        if (p != null) {
            p.sendStatusMessage(new StringTextComponent("Строю город, это займёт несколько секунд..."), true);
        }

        // 1) земля, дороги, расчистка
        for (int tx = 0; tx < SIZE / 16; tx++) {
            for (int tz = 0; tz < SIZE / 16; tz++) {
                final int bx = ox + tx * 16;
                final int bz = oz + tz * 16;
                QUEUE.add(() -> ground(w, bx, bz, ox, oz, gy, types));
            }
        }
        // 2) здания, парки, площадь
        for (int cx = 0; cx < CELLS; cx++) {
            for (int cz = 0; cz < CELLS; cz++) {
                final int fx = cx;
                final int fz = cz;
                QUEUE.add(() -> cell(w, ox, oz, gy, fx, fz, types[fx][fz], r));
            }
        }
        // 3) мусор по всему городу
        for (int tx = 0; tx < SIZE / 16; tx++) {
            for (int tz = 0; tz < SIZE / 16; tz++) {
                final int bx = ox + tx * 16;
                final int bz = oz + tz * 16;
                QUEUE.add(() -> trash(w, bx, bz, ox, oz, gy, types, r));
            }
        }
        QUEUE.add(() -> {
            if (p != null) {
                p.sendStatusMessage(new StringTextComponent("Город готов! Собирай мусор и неси скупщику на площади"), true);
            }
        });
        return true;
    }

    // ---------- земля ----------

    private static BlockState groundBlock(int lx, int lz, int[][] types) {
        int cx = lx / CELL;
        int cz = lz / CELL;
        int ix = lx % CELL;
        int iz = lz % CELL;
        boolean rx = ix < ROAD;
        boolean rz = iz < ROAD;
        if (rx && rz) {
            return Blocks.GRAY_CONCRETE.getDefaultState();
        }
        if (rx) {
            return (ix == 0 || ix == ROAD - 1) ? Blocks.SMOOTH_STONE.getDefaultState() : Blocks.GRAY_CONCRETE.getDefaultState();
        }
        if (rz) {
            return (iz == 0 || iz == ROAD - 1) ? Blocks.SMOOTH_STONE.getDefaultState() : Blocks.GRAY_CONCRETE.getDefaultState();
        }
        switch (types[cx][cz]) {
            case 3:
                return Blocks.GRASS_BLOCK.getDefaultState();
            case 4:
                return Blocks.COARSE_DIRT.getDefaultState();
            default:
                return Blocks.POLISHED_ANDESITE.getDefaultState();
        }
    }

    private static void ground(ServerWorld w, int bx, int bz, int ox, int oz, int gy, int[][] types) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        BlockState air = Blocks.AIR.getDefaultState();
        BlockState dirt = Blocks.DIRT.getDefaultState();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = bx + dx;
                int z = bz + dz;
                m.setPos(x, gy, z);
                w.setBlockState(m, groundBlock(x - ox, z - oz, types), FLAGS);
                for (int y = gy - 1; y >= gy - 8; y--) {
                    m.setPos(x, y, z);
                    BlockState s = w.getBlockState(m);
                    if (s.isAir() || s.getMaterial().isReplaceable() || !s.getFluidState().isEmpty()) {
                        w.setBlockState(m, dirt, FLAGS);
                    } else {
                        break;
                    }
                }
                for (int y = gy + 1; y <= gy + 24; y++) {
                    m.setPos(x, y, z);
                    if (!w.getBlockState(m).isAir()) {
                        w.setBlockState(m, air, FLAGS);
                    }
                }
            }
        }
    }

    // ---------- кварталы ----------

    private static void set(ServerWorld w, int x, int y, int z, BlockState s) {
        w.setBlockState(new BlockPos(x, y, z), s, FLAGS);
    }

    private static void lamp(ServerWorld w, int x, int z, int gy) {
        BlockState fence = Blocks.OAK_FENCE.getDefaultState();
        for (int y = 1; y <= 4; y++) {
            set(w, x, gy + y, z, fence);
        }
        set(w, x, gy + 5, z, Blocks.LANTERN.getDefaultState());
    }

    private static void cell(ServerWorld w, int ox, int oz, int gy, int cx, int cz, int type, Random r) {
        int cx0 = ox + cx * CELL;
        int cz0 = oz + cz * CELL;
        for (int k = ROAD; k < CELL; k++) {
            if (k % 8 == 4) {
                lamp(w, cx0, cz0 + k, gy);
                lamp(w, cx0 + k, cz0, gy);
            }
        }
        int ps = CELL - ROAD;
        int px = cx0 + ROAD;
        int pz = cz0 + ROAD;

        if (type == 0) {
            int floors = 2 + r.nextInt(5);
            int bw = 14 + r.nextInt(9);
            int bd = 14 + r.nextInt(9);
            int x0 = px + (ps - bw) / 2;
            int z0 = pz + (ps - bd) / 2;
            build(w, x0, z0, bw, bd, gy, floors,
                    WALLS[r.nextInt(WALLS.length)], ROOFS[r.nextInt(ROOFS.length)]);
            if (r.nextInt(10) < 7) {
                npc(w, x0 + bw / 2 + 0.5, gy + 1, z0 + bd / 2 + 0.5, null, VillagerProfession.NONE, null);
            }
        } else if (type == 1 || type == 2) {
            int bw = 18;
            int bd = 14;
            int x0 = px + (ps - bw) / 2;
            int z0 = pz + (ps - bd) / 2;
            boolean hardware = type == 1;
            build(w, x0, z0, bw, bd, gy, 1,
                    hardware ? Blocks.ORANGE_TERRACOTTA : Blocks.GREEN_TERRACOTTA, Blocks.STONE_BRICKS);
            if (hardware) {
                npc(w, x0 + bw / 2 + 0.5, gy + 1, z0 + bd / 2 + 0.5, "Строймаркет",
                        VillagerProfession.MASON, hardwareOffers());
            } else {
                npc(w, x0 + bw / 2 + 0.5, gy + 1, z0 + bd / 2 + 0.5, "Скупщик",
                        VillagerProfession.ARMORER, buyerOffers());
            }
        } else if (type == 3) {
            BlockState log = Blocks.OAK_LOG.getDefaultState();
            BlockState leaves = Blocks.OAK_LEAVES.getDefaultState().with(LeavesBlock.PERSISTENT, true);
            for (int k = 0; k < 8; k++) {
                int tx = px + 2 + r.nextInt(ps - 4);
                int tz = pz + 2 + r.nextInt(ps - 4);
                int h = 4 + r.nextInt(2);
                for (int y = 1; y <= h; y++) {
                    set(w, tx, gy + y, tz, log);
                }
                for (int dx = -2; dx <= 2; dx++) {
                    for (int dz = -2; dz <= 2; dz++) {
                        for (int dy = h - 2; dy <= h + 1; dy++) {
                            if (Math.abs(dx) == 2 && Math.abs(dz) == 2) {
                                continue;
                            }
                            if (dx == 0 && dz == 0 && dy <= h) {
                                continue;
                            }
                            if (dy == h + 1 && (Math.abs(dx) > 1 || Math.abs(dz) > 1)) {
                                continue;
                            }
                            BlockPos pos = new BlockPos(tx + dx, gy + dy, tz + dz);
                            if (w.isAirBlock(pos)) {
                                w.setBlockState(pos, leaves, FLAGS);
                            }
                        }
                    }
                }
            }
        } else if (type == 5) {
            stall(w, px + 2, pz + 10, gy, Blocks.GREEN_WOOL, "Скупщик",
                    VillagerProfession.ARMORER, buyerOffers());
            stall(w, px + 10, pz + 10, gy, Blocks.ORANGE_WOOL, "Строймаркет",
                    VillagerProfession.MASON, hardwareOffers());
            stall(w, px + 18, pz + 10, gy, Blocks.BLUE_WOOL, "Бизнес-агент",
                    VillagerProfession.LIBRARIAN, businessOffers());
        }
    }

    private static void build(ServerWorld w, int x0, int z0, int bw, int bd, int gy,
                              int floors, Block wall, Block roof) {
        BlockPos.Mutable m = new BlockPos.Mutable();
        BlockState wallS = wall.getDefaultState();
        BlockState roofS = roof.getDefaultState();
        BlockState glass = Blocks.GLASS.getDefaultState();
        BlockState planks = Blocks.OAK_PLANKS.getDefaultState();
        int doorX = x0 + bw / 2;
        int ladX = x0 + 1;
        int ladZ = z0 + bd / 2;
        for (int x = x0; x < x0 + bw; x++) {
            for (int z = z0; z < z0 + bd; z++) {
                boolean edge = x == x0 || x == x0 + bw - 1 || z == z0 || z == z0 + bd - 1;
                boolean corner = (x == x0 || x == x0 + bw - 1) && (z == z0 || z == z0 + bd - 1);
                for (int f = 0; f < floors; f++) {
                    int yb = gy + 1 + f * 4;
                    for (int dy = 0; dy < 4; dy++) {
                        BlockState s;
                        if (dy == 3) {
                            if (!edge && x == ladX && z == ladZ && f < floors - 1) {
                                continue;
                            }
                            s = (f == floors - 1) ? roofS : (edge ? wallS : planks);
                        } else if (edge) {
                            if (f == 0 && z == z0 + bd - 1 && x >= doorX - 1 && x <= doorX && dy < 2) {
                                continue;
                            }
                            boolean win = dy >= 1 && !corner && ((x + z) % 3 == 0);
                            s = win ? glass : wallS;
                        } else {
                            continue;
                        }
                        m.setPos(x, yb + dy, z);
                        w.setBlockState(m, s, FLAGS);
                    }
                }
            }
        }
        if (floors > 1) {
            BlockState ladder = Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.EAST);
            for (int y = gy + 1; y <= gy + 1 + (floors - 1) * 4 + 2; y++) {
                set(w, ladX, y, ladZ, ladder);
            }
        }
        BlockState lantern = Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true);
        for (int f = 0; f < floors; f++) {
            int y = gy + 1 + f * 4 + 2;
            set(w, x0 + bw / 3, y, z0 + bd / 3, lantern);
            set(w, x0 + 2 * bw / 3, y, z0 + 2 * bd / 3, lantern);
        }
    }

    private static void stall(ServerWorld w, int x, int z, int gy, Block wool, String name,
                              VillagerProfession prof, List<MerchantOffer> offers) {
        BlockState planks = Blocks.OAK_PLANKS.getDefaultState();
        BlockState log = Blocks.OAK_LOG.getDefaultState();
        BlockState roof = wool.getDefaultState();
        for (int dx = 0; dx < 6; dx++) {
            for (int dz = 0; dz < 6; dz++) {
                set(w, x + dx, gy, z + dz, planks);
                set(w, x + dx, gy + 4, z + dz, roof);
            }
        }
        for (int dy = 1; dy <= 3; dy++) {
            set(w, x, gy + dy, z, log);
            set(w, x + 5, gy + dy, z, log);
            set(w, x, gy + dy, z + 5, log);
            set(w, x + 5, gy + dy, z + 5, log);
        }
        for (int dx = 1; dx <= 4; dx++) {
            set(w, x + dx, gy + 1, z, planks);
            set(w, x + dx, gy + 2, z, planks);
        }
        set(w, x + 2, gy + 3, z + 2, Blocks.LANTERN.getDefaultState().with(LanternBlock.HANGING, true));
        npc(w, x + 3.0, gy + 1, z + 3.0, name, prof, offers);
    }

    // ---------- жители и торговля ----------

    private static void npc(ServerWorld w, double x, double y, double z, String name,
                            VillagerProfession prof, List<MerchantOffer> offers) {
        VillagerEntity v = EntityType.VILLAGER.create(w);
        if (v == null) {
            return;
        }
        v.setLocationAndAngles(x, y, z, 0.0F, 0.0F);
        v.setVillagerData(v.getVillagerData().withProfession(prof));
        if (name != null) {
            v.setCustomName(new StringTextComponent(name));
            v.setCustomNameVisible(true);
        }
        if (offers != null) {
            v.setNoAI(true);
            v.setInvulnerable(true);
            MerchantOffers list = v.getOffers();
            list.clear();
            list.addAll(offers);
        }
        v.enablePersistence();
        w.addEntity(v);
    }

    private static ItemStack h(int n) {
        return new ItemStack(ModItems.HRYVNIA.get(), n);
    }

    private static MerchantOffer o(ItemStack a, ItemStack result) {
        return new MerchantOffer(a, result, BIG, 0, 0.0F);
    }

    private static MerchantOffer o2(ItemStack a, ItemStack b, ItemStack result) {
        return new MerchantOffer(a, b, result, BIG, 0, 0.0F);
    }

    private static List<MerchantOffer> buyerOffers() {
        List<MerchantOffer> l = new ArrayList<>();
        l.add(o(new ItemStack(ModItems.BOTTLE.get(), 1), h(1)));
        l.add(o(new ItemStack(ModItems.CAN.get(), 1), h(2)));
        l.add(o(new ItemStack(ModItems.SCRAP_METAL.get(), 1), h(5)));
        l.add(o(new ItemStack(ModItems.BOTTLE.get(), 16), h(16)));
        l.add(o(new ItemStack(ModItems.CAN.get(), 16), h(32)));
        l.add(o(new ItemStack(ModItems.SCRAP_METAL.get(), 16), h(80)));
        return l;
    }

    private static List<MerchantOffer> hardwareOffers() {
        List<MerchantOffer> l = new ArrayList<>();
        l.add(o(h(2), new ItemStack(Blocks.OAK_PLANKS, 16)));
        l.add(o(h(3), new ItemStack(Blocks.COBBLESTONE, 16)));
        l.add(o(h(4), new ItemStack(Blocks.GLASS, 16)));
        l.add(o(h(5), new ItemStack(Blocks.BRICKS, 16)));
        l.add(o(h(6), new ItemStack(Blocks.WHITE_CONCRETE, 16)));
        l.add(o(h(8), new ItemStack(Blocks.STONE_BRICKS, 32)));
        l.add(o(h(12), new ItemStack(ModBlocks.STEEL_BEAM.get(), 8)));
        l.add(o(h(40), new ItemStack(ModBlocks.STEEL_BEAM.get(), 32)));
        return l;
    }

    private static List<MerchantOffer> businessOffers() {
        List<MerchantOffer> l = new ArrayList<>();
        l.add(o(h(40), new ItemStack(ModBlocks.BIZ_KIOSK.get(), 1)));
        l.add(o2(h(64), h(36), new ItemStack(ModBlocks.BIZ_SHOP.get(), 1)));
        l.add(o2(h(64), h(64), new ItemStack(ModBlocks.BIZ_SERVICE.get(), 1)));
        return l;
    }

    // ---------- мусор ----------

    private static double trashChance(int lx, int lz, int[][] types) {
        int cx = lx / CELL;
        int cz = lz / CELL;
        int ix = lx % CELL;
        int iz = lz % CELL;
        boolean rx = ix < ROAD;
        boolean rz = iz < ROAD;
        if (rx && rz) {
            return 0.003;
        }
        if (rx) {
            return (ix == 0 || ix == ROAD - 1) ? 0.05 : 0.004;
        }
        if (rz) {
            return (iz == 0 || iz == ROAD - 1) ? 0.05 : 0.004;
        }
        switch (types[cx][cz]) {
            case 4:
                return 0.15;
            case 3:
                return 0.01;
            case 5:
                return 0.004;
            default:
                return 0.03;
        }
    }

    private static void trash(ServerWorld w, int bx, int bz, int ox, int oz, int gy, int[][] types, Random r) {
        BlockState pile = ModBlocks.TRASH_PILE.get().getDefaultState();
        for (int dx = 0; dx < 16; dx++) {
            for (int dz = 0; dz < 16; dz++) {
                int x = bx + dx;
                int z = bz + dz;
                if (r.nextDouble() < trashChance(x - ox, z - oz, types)) {
                    BlockPos pos = new BlockPos(x, gy + 1, z);
                    if (w.isAirBlock(pos) && w.canSeeSky(pos)) {
                        w.setBlockState(pos, pile, FLAGS);
                    }
                }
            }
        }
    }
}
