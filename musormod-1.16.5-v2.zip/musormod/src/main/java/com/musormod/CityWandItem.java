package com.musormod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUseContext;
import net.minecraft.util.ActionResultType;
import net.minecraft.world.World;
import net.minecraft.world.server.ServerWorld;

public class CityWandItem extends Item {
    public CityWandItem(Item.Properties props) {
        super(props);
    }

    @Override
    public ActionResultType onItemUse(ItemUseContext ctx) {
        World w = ctx.getWorld();
        if (!w.isRemote && w instanceof ServerWorld) {
            PlayerEntity p = ctx.getPlayer();
            boolean started = CityBuilder.start((ServerWorld) w, ctx.getPos(), p);
            if (started && p != null && !p.isCreative()) {
                ctx.getItem().shrink(1);
            }
        }
        return ActionResultType.SUCCESS;
    }
}
