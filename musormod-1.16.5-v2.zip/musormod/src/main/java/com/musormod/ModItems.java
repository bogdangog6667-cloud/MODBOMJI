package com.musormod;

import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroup;
import net.minecraftforge.fml.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MusorMod.MODID);

    public static final RegistryObject<Item> BOTTLE = ITEMS.register("bottle",
            () -> new Item(new Item.Properties().group(ItemGroup.MISC)));
    public static final RegistryObject<Item> CAN = ITEMS.register("can",
            () -> new Item(new Item.Properties().group(ItemGroup.MISC)));
    public static final RegistryObject<Item> SCRAP_METAL = ITEMS.register("scrap_metal",
            () -> new Item(new Item.Properties().group(ItemGroup.MISC)));
    public static final RegistryObject<Item> HRYVNIA = ITEMS.register("hryvnia",
            () -> new Item(new Item.Properties().group(ItemGroup.MISC)));
    public static final RegistryObject<Item> CITY_WAND = ITEMS.register("city_wand",
            () -> new CityWandItem(new Item.Properties().group(ItemGroup.MISC).maxStackSize(1)));

    public static final RegistryObject<Item> TRASH_PILE = ITEMS.register("trash_pile",
            () -> new BlockItem(ModBlocks.TRASH_PILE.get(), new Item.Properties().group(ItemGroup.DECORATIONS)));
    public static final RegistryObject<Item> STEEL_BEAM = ITEMS.register("steel_beam",
            () -> new BlockItem(ModBlocks.STEEL_BEAM.get(), new Item.Properties().group(ItemGroup.BUILDING_BLOCKS)));
    public static final RegistryObject<Item> BIZ_KIOSK = ITEMS.register("biz_kiosk",
            () -> new BlockItem(ModBlocks.BIZ_KIOSK.get(), new Item.Properties().group(ItemGroup.DECORATIONS)));
    public static final RegistryObject<Item> BIZ_SHOP = ITEMS.register("biz_shop",
            () -> new BlockItem(ModBlocks.BIZ_SHOP.get(), new Item.Properties().group(ItemGroup.DECORATIONS)));
    public static final RegistryObject<Item> BIZ_SERVICE = ITEMS.register("biz_service",
            () -> new BlockItem(ModBlocks.BIZ_SERVICE.get(), new Item.Properties().group(ItemGroup.DECORATIONS)));
}
